# StarNet Fichas — versión básica

Proyecto Android nativo para crear usuarios Hotspot en un MikroTik RouterOS 6 mediante API.

## Datos usados en este prototipo
- Router: 192.168.5.1
- API: TCP 8728
- Usuario API: appfichas
- Contraseña API: StarNet123!

## Funciones
- Nombre de ficha
- Contraseña
- 1 h / 3 h / 6 h / 12 h / 24 h
- Crea `/ip/hotspot/user` con `limit-uptime`

## Importante
Es un prototipo de prueba. La contraseña de la API está embebida en el código. Para una versión real conviene crear una pantalla de configuración y almacenar las credenciales de forma segura, además de limitar permisos del usuario API.

## Compilar
Abrir la carpeta en Android Studio con internet disponible para que Gradle descargue el Android Gradle Plugin. Luego Build > Build APK(s).
