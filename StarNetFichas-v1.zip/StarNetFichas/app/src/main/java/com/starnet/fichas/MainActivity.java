package com.starnet.fichas;

import android.app.*; import android.os.*; import android.graphics.Color; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
    EditText name, pass; Spinner time; Button create; TextView status;
    // Prototipo local. Estos datos corresponden al RB750Gr3 del usuario.
    static final String ROUTER="192.168.5.1", API_USER="appfichas", API_PASS="StarNet123!";
    String[] labels={"1 hora","3 horas","6 horas","12 horas","24 horas"};
    String[] values={"1h","3h","6h","12h","1d"};
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(0,8,0,8); return t; }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,36,40,28); root.setBackgroundColor(Color.WHITE);
        TextView title=tv("STAR NET",28); title.setTextColor(Color.rgb(20,70,130)); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("FICHAS WiFi",18); sub.setGravity(Gravity.CENTER); root.addView(sub);
        root.addView(tv("Nombre de ficha",16)); name=new EditText(this); name.setHint("Ej: JUAN"); name.setSingleLine(true); root.addView(name);
        root.addView(tv("Contraseña",16)); pass=new EditText(this); pass.setHint("Ej: 7K4P92"); pass.setSingleLine(true); root.addView(pass);
        root.addView(tv("Tiempo",16)); time=new Spinner(this); time.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels)); root.addView(time);
        create=new Button(this); create.setText("CREAR FICHA"); root.addView(create,new LinearLayout.LayoutParams(-1,-2));
        status=tv("Listo. Conectado al RB: "+ROUTER,14); root.addView(status);
        create.setOnClickListener(v->create()); setContentView(root);
    }
    void create(){
        String n=name.getText().toString().trim(), p=pass.getText().toString().trim(); int i=time.getSelectedItemPosition();
        if(n.isEmpty()||p.isEmpty()){status.setText("Escribe nombre y contraseña."); return;}
        create.setEnabled(false); status.setText("Creando ficha...");
        new Thread(()->{ String msg; try(RouterOsApi api=new RouterOsApi(ROUTER,8728,5000)){ api.login(API_USER,API_PASS); api.addHotspotUser(n,p,values[i]); msg="✅ FICHA CREADA\n\nUsuario: "+n+"\nCódigo: "+p+"\nTiempo: "+labels[i]; }catch(Exception e){msg="❌ Error: "+e.getMessage();}
            runOnUiThread(()->{status.setText(msg); create.setEnabled(true);}); }).start();
    }
}
