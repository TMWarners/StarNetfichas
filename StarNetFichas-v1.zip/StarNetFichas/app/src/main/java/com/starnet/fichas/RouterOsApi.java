package com.starnet.fichas;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

public class RouterOsApi implements Closeable {
    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;

    public RouterOsApi(String host, int port, int timeoutMs) throws IOException {
        socket = new Socket();
        socket.connect(new java.net.InetSocketAddress(host, port), timeoutMs);
        socket.setSoTimeout(timeoutMs);
        in = socket.getInputStream(); out = socket.getOutputStream();
    }

    private void writeLen(int len) throws IOException {
        if (len < 0x80) out.write(len);
        else if (len < 0x4000) { out.write((len >> 8) | 0x80); out.write(len & 0xff); }
        else if (len < 0x200000) { out.write((len >> 16) | 0xC0); out.write((len >> 8) & 0xff); out.write(len & 0xff); }
        else if (len < 0x10000000) { out.write((len >> 24) | 0xE0); out.write((len >> 16)&0xff); out.write((len >> 8)&0xff); out.write(len&0xff); }
        else { out.write(0xF0); out.write((len >> 24)&0xff); out.write((len >> 16)&0xff); out.write((len >> 8)&0xff); out.write(len&0xff); }
    }
    private int readLen() throws IOException {
        int b=in.read(); if(b<0) throw new EOFException();
        if((b&0x80)==0) return b;
        if((b&0xC0)==0x80) return ((b&0x3f)<<8)|in.read();
        if((b&0xE0)==0xC0) return ((b&0x1f)<<16)|(in.read()<<8)|in.read();
        if((b&0xF0)==0xE0) return ((b&0x0f)<<24)|(in.read()<<16)|(in.read()<<8)|in.read();
        if(b==0xF0) return (in.read()<<24)|(in.read()<<16)|(in.read()<<8)|in.read();
        throw new IOException("Bad API length");
    }
    private void word(String s) throws IOException { byte[] d=s.getBytes(StandardCharsets.UTF_8); writeLen(d.length); out.write(d); }
    private List<String> sentence(String... words) throws IOException { for(String w:words) word(w); word(""); out.flush(); List<String> r=new ArrayList<>(); while(true){ int n=readLen(); byte[] d=new byte[n]; int p=0; while(p<n){int x=in.read(d,p,n-p); if(x<0)throw new EOFException(); p+=x;} String w=new String(d,StandardCharsets.UTF_8); if(w.isEmpty()) break; r.add(w); } return r; }

    public void login(String user, String password) throws Exception {
        List<String> r = sentence("/login", "=name="+user, "=password="+password);
        String ret=null; for(String w:r) if(w.startsWith("=ret=")) ret=w.substring(5);
        if(ret!=null){
            byte[] challenge=hex(ret); MessageDigest md=MessageDigest.getInstance("MD5");
            md.update((byte)0); md.update(password.getBytes(StandardCharsets.UTF_8)); md.update(challenge);
            String response="00"+hex(md.digest());
            r=sentence("/login","=name="+user,"=response="+response);
        }
        for(String w:r) if(w.startsWith("!trap")) throw new IOException("Usuario o contraseña API incorrectos");
    }
    public void addHotspotUser(String name,String password,String limitUptime) throws Exception {
        List<String> r=sentence("/ip/hotspot/user/add","=name="+name,"=password="+password,"=limit-uptime="+limitUptime);
        for(String w:r) if(w.equals("!trap")) throw new IOException("El MikroTik rechazó la ficha (¿nombre ya existe?)");
    }
    private static byte[] hex(String s){ int n=s.length(); byte[] b=new byte[n/2]; for(int i=0;i<n;i+=2)b[i/2]=(byte)Integer.parseInt(s.substring(i,i+2),16); return b; }
    private static String hex(byte[] b){ StringBuilder s=new StringBuilder(); for(byte x:b)s.append(String.format(Locale.US,"%02x",x&255)); return s.toString(); }
    public void close(){ try{socket.close();}catch(Exception ignored){} }
}
